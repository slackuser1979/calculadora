package com.wescleyr.activitycalculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class calculadora extends AppCompatActivity {

    private EditText ed_numero1, ed_numero2, ed_resultado;
    private Button somar, subtrair, multiplicar, dividir, percentual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        ed_numero1 = (EditText) findViewById(R.id.ed_numero1);
        ed_numero2 = (EditText) findViewById(R.id.ed_numero2);
        ed_resultado = (EditText) findViewById(R.id.ed_resultado);

        somar = (Button) findViewById(R.id.somar);
        subtrair = (Button) findViewById(R.id.subtrair);
        multiplicar = (Button) findViewById(R.id.multiplicar);
        dividir = (Button) findViewById(R.id.dividir);
        percentual = (Button) findViewById(R.id.percentual);

        somar.setOnClickListener(new View.OnClickListener() {

            double valor1, valor2, resulta;

            @Override
            public void onClick(View v) {
                valor1 = Double.parseDouble(ed_numero1.getText().toString());
                valor2 = Double.parseDouble(ed_numero2.getText().toString());

                resulta = valor1 + valor2;

                ed_resultado.setText(String.valueOf(resulta));
            }
        });
        subtrair.setOnClickListener(new View.OnClickListener() {

            double valor1, valor2, resulta;

            @Override
            public void onClick(View v) {
                valor1 = Double.parseDouble(ed_numero1.getText().toString());
                valor2 = Double.parseDouble(ed_numero2.getText().toString());

                resulta = valor1 - valor2;

                ed_resultado.setText(String.valueOf(resulta));
            }
        });
        multiplicar.setOnClickListener(new View.OnClickListener() {

            double valor1, valor2, resulta;

            @Override
            public void onClick(View v) {
                valor1 = Double.parseDouble(ed_numero1.getText().toString());
                valor2 = Double.parseDouble(ed_numero2.getText().toString());

                resulta = valor1 * valor2;

                ed_resultado.setText(String.valueOf(resulta));
            }
        });
        dividir.setOnClickListener(new View.OnClickListener() {

            double valor1, valor2, resulta;

            @Override
            public void onClick(View v) {
                valor1 = Double.parseDouble(ed_numero1.getText().toString());
                valor2 = Double.parseDouble(ed_numero2.getText().toString());

                resulta = valor1 / valor2;

                ed_resultado.setText(String.valueOf(resulta));
            }
        });
        percentual.setOnClickListener(new View.OnClickListener() {

            double valor1, valor2, resulta;

            @Override
            public void onClick(View v) {
                valor1 = Double.parseDouble(ed_numero1.getText().toString());
                valor2 = Double.parseDouble(ed_numero2.getText().toString());

                resulta = valor1 * (1 + (valor2 / 100));

                ed_resultado.setText(String.valueOf(resulta));
            }
        });
    }
}